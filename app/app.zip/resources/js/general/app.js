(function (SG, undefined)
{
	/**
	 * @ngdoc function 
	 * @name SG
	 * @id SG
	 * @description
	 * @Author Yateender Khedar
	 * Set up our SG website parameters for AngularJS.
	**/
	SG.Version 		= "0.0.0";
	SG.PartialsPath 	= "partials/";
	// SG.ServerUrl 	= 'http://144.76.237.246:6060/superkids/r1/';
	SG.ServerUrl 	= 'http://128.199.196.34:8080/smartgrowth/r1/';
	SG.Service 		= {};
	SG.Modules 		= {};
	SG.Configs 		= {};
	SG.Filters 		= {};
	SG.Controllers 	= {};
	SG.Directives 		= {};

}(window.SG = window.SG || {} ));